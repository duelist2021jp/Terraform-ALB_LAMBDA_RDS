import json
import boto3
import psycopg2
import os
from decimal import Decimal

# Secrets Managerから接続情報を取得する関数
def get_secret(secret_name):

    client = boto3.client("secretsmanager")
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

def lambda_handler(event, context):

    allowed_tables = ['accounts', 'items'] # 許可するテーブル名のリスト

    http_method = event.get('httpMethod', 'GET')
    path = event.get('path', '/')
    query_params = event.get('queryStringParameters') or {}
    
    if query_params:
        # ALB経由の場合
        table = query_params.get('target_table', 'accounts')
        limit = query_params.get('limit_count', 10)
    else:
        # 直接テスト（または以前の構成）の場合
        table = event.get('target_table', 'accounts')
        limit = event.get('limit_count', 10)

    # 注意: クエリパラメータはすべて「文字列」として渡されるため、数値に変換が必要
    try:
        limit = int(limit)
    except (ValueError, TypeError):
        limit = 10

    if table not in allowed_tables:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body':json.dumps({
                'success': False,
                'error': 'Invalid Table Name',
                'message': str(e)
            }) 
        }

    # 2. 環境変数から必要情報を取得
    dbname = os.environ["dbname"]
    db_host = os.environ["dbhost"]
    db_port = os.environ["port_number"]
    secret_name = os.environ["Secret_Name"]

    # 2. Secrets Managerから認証情報を取得
    try:
        secret = get_secret(secret_name)
        db_user = secret.get('username')
        db_password = secret.get('password')
    except Exception as e:
        return {
            'statusCode': 500,
            'statusDescription': '500 Internal Server Error',
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'success': False,
                'error': 'Failed to retrieve database credentials',
                'message': str(e)
            })
        }

    try:
        # 3. RDSに接続
        conn = psycopg2.connect(
            host=db_host,
            database=dbname,
            user=db_user,
            password=db_password,
            port=db_port,
            connect_timeout=20
        )
        
        with conn.cursor() as cur:
            # 4. SQL実行 (テーブル名は識別子なのでquote_ident的に扱うか、バリデーションが必要)
            # 注意: テーブル名は動的に変える場合、信頼できる入力のみ許可してください
            query = f"SELECT * FROM {table} LIMIT %s;"
            cur.execute(query, (limit,))
            
            # 結果の取得
            rows = cur.fetchall()
            # カラム名を取得して辞書形式に変換すると見やすくなります
            columns = [desc[0] for desc in cur.description]
            result = [dict(zip(columns, row)) for row in rows]

        conn.close()

        response_body = json.dumps(result, default=str) 

        return {
            'isBase64Encoded': False,
            'statusCode': 200,
            'statusDescription': '200 OK',
            'headers': {
               'Content-Type': 'application/json'
             },
            'body': response_body
        }

    except Exception as e:
        # エラー内容を辞書にしてJSON化する
        error_payload = {
            "error": "true",
            "message": str(e),
             "type": "RuntimeError"
        }
        return {
            'statusCode': 500,
            'statusDescription': '500 Error',
            'headers': {
               'Content-Type': 'application/json'
             },
            'body': json.dumps(error_payload) # JSON文字列として返す
        }
